<footer>
    <div class="footer-content">
        <div class="footer-text">
            <p>2024 Детский бутик. Все права защищены.</p>
        </div>
        <div class="logo">
            <a href="index.php"><img src="/img/logo.png" alt="logo"></a>
        </div>
    </div>
</footer>
