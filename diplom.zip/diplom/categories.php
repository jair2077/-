
<?php 
$pageTitle = "Детский бутик";
include('header.php'); 
?>

<!-- Категории -->
<section class="categories">
    <h2>Категории</h2>
    <ul>
        <li><a href="t-shirts.html">Футболки</a></li>
        <li><a href="dresses.html">Платья</a></li>
        <li><a href="shorts.html">Шорты</a></li>
        <li><a href="jeans.html">Джинсы</a></li>
        <li><a href="hoody.html">Толстовки</a></li>
        <!-- и другие категории -->
    </ul>
</section>

<!-- Футер сайта, если есть -->


<script src="script.js"></script>
<!-- Футер сайта, если есть -->
<?php include('footer.php'); ?>